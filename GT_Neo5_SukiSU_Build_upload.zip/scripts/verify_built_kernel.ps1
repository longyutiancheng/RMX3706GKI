﻿# verify_built_kernel.ps1 — 核对云编译/本地构建产出的新内核
# 用法:
#   powershell -ExecutionPolicy Bypass -File verify_built_kernel.ps1 <刷机zip或Image>
# 例:
#   powershell -ExecutionPolicy Bypass -File verify_built_kernel.ps1 "F:\deepseek\5.10_SukiSU_Ultra_lz4kd_susfs-main_20260820.zip"
# 或直接对 Image:
#   powershell -ExecutionPolicy Bypass -File verify_built_kernel.ps1 "F:\deepseek\kernel_pkg\Image"
param([Parameter(Mandatory = $true)][string]$Path)

$ErrorActionPreference = 'Stop'
$tmp = Join-Path $env:TEMP ("ksu_verify_" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

function Find-Str($bytes, $str, $from = 0) {
    $pat = [System.Text.Encoding]::ASCII.GetBytes($str)
    for ($i = $from; $i -le $bytes.Length - $pat.Length; $i++) {
        $m = $true
        for ($j = 0; $j -lt $pat.Length; $j++) { if ($bytes[$i + $j] -ne $pat[$j]) { $m = $false; break } }
        if ($m) { return $i }
    }
    return -1
}

try {
    # ---- 1. 取得 Image ----
    $image = ""
    if ($Path -like '*.zip') {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
        try {
            $e = $zip.Entries | Where-Object { $_.FullName -eq 'Image' } | Select-Object -First 1
            if (-not $e) { throw "zip 里找不到 Image（这不是 AnyKernel 刷机包？）" }
            $tmpImg = Join-Path $tmp 'Image'
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, $tmpImg, $true)
            $image = $tmpImg
        } finally { $zip.Dispose() }
    } else {
        if (-not (Test-Path $Path)) { throw "文件不存在: $Path" }
        $image = $Path
    }

    $bytes = [System.IO.File]::ReadAllBytes($image)
    "Image: $image ($([math]::Round($bytes.Length/1MB,2)) MB)"
    ""

    # ---- 2. 版本串（跳过格式串 "Linux version %s"，取真实版本行）----
    $li = -1; $start = 0
    while ($true) {
        $idx = Find-Str $bytes 'Linux version' $start
        if ($idx -lt 0) { break }
        $next = $bytes[$idx + 14]
        if ($next -ge 48 -and $next -le 57) { $li = $idx; break }
        $start = $idx + 1
    }
    if ($li -ge 0) {
        $end = $li; while ($end -lt $bytes.Length -and $bytes[$end] -ne 0 -and $bytes[$end] -ne 10) { $end++ }
        "内核版本: $([System.Text.Encoding]::ASCII.GetString($bytes[$li..($end-1)]))"
    } else { "内核版本: 未找到 'Linux version'（异常！）" }

    # ---- 3. susfs ----
    $si = Find-Str $bytes 'susfs is initialized'
    if ($si -ge 0) {
        $end = $si; while ($end -lt $bytes.Length -and $bytes[$end] -ne 0) { $end++ }
        "susfs:    $([System.Text.Encoding]::ASCII.GetString($bytes[$si..($end-1)]))"
    } else { "susfs:    未找到（异常！）" }

    # ---- 4. IKCONFIG ----
    $st = Find-Str $bytes 'IKCFG_ST'; $ed = Find-Str $bytes 'IKCFG_ED'
    if ($st -ge 0 -and $ed -gt $st) {
        $blob = New-Object byte[] ($ed - $st - 8)
        [Array]::Copy($bytes, $st + 8, $blob, 0, $blob.Length)
        $ms = New-Object System.IO.MemoryStream
        $gz = New-Object System.IO.Compression.GZipStream((New-Object System.IO.MemoryStream(,$blob)), [System.IO.Compression.CompressionMode]::Decompress)
        $gz.CopyTo($ms); $gz.Dispose()
        $cfg = [System.Text.Encoding]::UTF8.GetString($ms.ToArray())
        $cfgOut = Join-Path (Split-Path $Path) 'built.config'
        [System.IO.File]::WriteAllText($cfgOut, $cfg)
        "IKCONFIG: 已提取 -> $cfgOut"
        ""
        "--- 功能选项核对 ---"
        ($cfg -split "`n") | Where-Object { $_ -match '^CONFIG_(KSU|KSU_SUSFS|KPM)' } | ForEach-Object { "  $_" }
        $ksu = ($cfg -split "`n") | Where-Object { $_ -eq 'CONFIG_KSU=y' }
        $sus = ($cfg -split "`n") | Where-Object { $_ -eq 'CONFIG_KSU_SUSFS=y' }
        ""
        if ($ksu -and $sus) { "结论: PASS — KSU 与 susfs 均已启用，可刷入。" }
        else { "结论: FAIL — KSU/susfs 未正确启用，请把 built.config 发给作者。" }
    } else {
        "IKCONFIG: 未找到（该内核未启用 CONFIG_IKCONFIG，跳过功能核对）"
    }
} finally {
    if ($tmp -and (Test-Path $tmp)) { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}
