#!/usr/bin/env bash
# ============================================================
# 备用路径：本地 WSL2 / Linux 构建的依赖安装脚本
# 用法: sudo bash scripts/install-deps-ubuntu.sh
# （与 GitHub Actions 运行器安装的依赖保持一致）
# ============================================================
set -euo pipefail

apt-get update
apt-get install -y --no-install-recommends \
    flex bison bc cpio zip unzip curl wget git \
    libssl-dev libelf-dev python3 binutils \
    build-essential

echo "[+] 依赖安装完成。接下来运行: ./build_kernel.sh"
echo "    （首次构建需联网下载内核源码约 2GB + clang 约 1GB，需 30~40GB 磁盘，编译 1~3 小时）"
