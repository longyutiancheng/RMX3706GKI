#!/usr/bin/env bash
# ============================================================
# Build SukiSU Ultra GKI 5.10 kernel for realme GT Neo5 (RMX3706)
#
# Rebuild of xiaoxiaow's "5.10_SukiSU_Ultra_lz4kd_40085" package
# using the LATEST SukiSU Ultra source (official susfs branch),
# GKI base android12-5.10 @ 5.10.236 (matches the device's ROM).
#
# Usage: ./build_kernel.sh [kernel_tag] [sukisu_ref] [clang_version] [susfs_variant]
#   kernel_tag : "auto" (find tag with SUBLEVEL=236) or e.g. android12-5.10-2025-05_r1
#   sukisu_ref : susfs_new (default, SukiSU 官方分支) | main | 提交号 | none
#   clang_version : AOSP clang dir name, default clang-r416183b (clang 12.0.5, matches stock)
#   susfs_variant : auto (默认, 自动尝试 SukiSU/kernelSU-Next/kernelSU) | 指定变体 | none
# ============================================================
set -euo pipefail

KERNEL_TAG_ARG="${1:-auto}"
SUKISU_REF="${2:-susfs_new}"
CLANG_VERSION="${3:-clang-r416183b}"

SRC_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="$SRC_ROOT/work"
OUT="$SRC_ROOT/out"
BUILD="$WORK/build"
mkdir -p "$WORK" "$OUT"

log() { echo "[+] $*"; }
die() { echo "[ERROR] $*" >&2; exit 1; }

# ---------- 0. pre-flight checks ----------
[ -d "$SRC_ROOT/template/tools" ] || die "template/tools 目录缺失：请确认已上传整个 template/（含 magiskboot、httools 等文件）"
[ -f "$SRC_ROOT/configs/gki-sukisu.config" ] || die "configs/gki-sukisu.config 缺失"

# ---------- 1. resolve AOSP kernel tag (SUBLEVEL = 236) ----------
resolve_kernel_tag() {
    if [ "$KERNEL_TAG_ARG" != "auto" ]; then echo "$KERNEL_TAG_ARG"; return; fi
    local months="2024-11_r1 2024-12_r1 2025-01_r1 2025-02_r1 2025-03_r1 2025-04_r1 2025-05_r1 2025-06_r1 2025-07_r1 2025-08_r1 2025-09_r1 2025-10_r1"
    local last=""
    local tag sl
    for m in $months; do
        tag="android12-5.10-$m"
        sl=""
        sl=$(curl -fsSL "https://android.googlesource.com/kernel/common/+/refs/tags/$tag/Makefile?format=TEXT" 2>/dev/null \
             | base64 -d 2>/dev/null | awk '/^SUBLEVEL/{print $3; exit}' || true)
        echo "      probe $tag -> SUBLEVEL=${sl:-?}" >&2
        if [ -n "$sl" ]; then last="$tag"; fi
        if [ "$sl" = "236" ]; then echo "$tag"; return; fi
    done
    if [ -n "$last" ]; then
        echo "      [warn] no tag with SUBLEVEL=236 found; using last existing tag: $last" >&2
        echo "$last"
    else
        echo "android12-5.10-2025-05_r1"
    fi
}
log "Resolving AOSP kernel tag ..."
KERNEL_TAG="$(resolve_kernel_tag | tail -n1)"
echo "      >> kernel tag = $KERNEL_TAG"

# ---------- 2. clone kernel source ----------
if [ ! -d "$WORK/kernel/.git" ]; then
    log "Cloning kernel/common @ $KERNEL_TAG (shallow)"
    git clone --depth 1 --branch "$KERNEL_TAG" \
        https://android.googlesource.com/kernel/common "$WORK/kernel"
fi
cd "$WORK/kernel"

# ---------- 3. AOSP clang toolchain ----------
download_clang() {
    local ver="$1" dir="$WORK/clang-$ver"
    if [ -x "$dir/bin/clang" ]; then echo "$dir"; return; fi
    log "Downloading AOSP clang: $ver"
    mkdir -p "$dir"
    local ok=0 br
    for br in master-kernel-build-2021 master-kernel-build-2022 master-kernel-build-2023 main; do
        local url="https://android.googlesource.com/platform/prebuilts/clang/host/linux-x86/+archive/refs/heads/$br/$ver.tar.gz"
        echo "      trying $url" >&2
        if curl -fsSL --retry 3 "$url" -o "$WORK/clang-$ver.tar.gz"; then
            tar -xf "$WORK/clang-$ver.tar.gz" -C "$dir" && ok=1 && break
        fi
    done
    [ "$ok" = 1 ] || return 1
    echo "$dir"
}

# ---------- 4. integrate SukiSU Ultra (+ susfs branch) ----------
# 解析 SukiSU 引用：全量克隆（所有分支可用）→ 按优先级检出（显式指定 → 常用 susfs 分支 → main），
# 并验证源码中确实包含 susfs 代码（防止静默丢失隐藏功能）。
resolve_sukisu_ref() {
    local refs="$1" ref
    for ref in $refs; do
        echo "      trying ref: $ref" >&2
        if git rev-parse --verify "refs/remotes/origin/$ref" >/dev/null 2>&1; then
            git checkout -f "$ref" >/dev/null 2>&1 && { echo "$ref"; return 0; }
        elif git rev-parse --verify "refs/tags/$ref" >/dev/null 2>&1; then
            git checkout -f "refs/tags/$ref" >/dev/null 2>&1 && { echo "$ref"; return 0; }
        elif git rev-parse --verify "$ref^{commit}" >/dev/null 2>&1; then
            git checkout -f "$ref" >/dev/null 2>&1 && { echo "$ref"; return 0; }
        fi
    done
    return 1
}

if [ "$SUKISU_REF" = "none" ]; then
    log "Skipping SukiSU integration (sukisu_ref=none)"
else
    log "Integrating SukiSU Ultra @ $SUKISU_REF"
    if [ ! -d "$WORK/KernelSU/.git" ]; then
        # 全量克隆（不用浅克隆）：所有分支都会成为远程跟踪分支，检出最可靠
        git clone https://github.com/SukiSU-Ultra/SukiSU-Ultra "$WORK/KernelSU"
    fi
    cd "$WORK/KernelSU"
    echo "      remote susfs refs available:"
    git ls-remote --heads --tags origin 2>/dev/null | grep -i susfs || echo "      (远程无 susfs 分支/tag)"
    RESOLVED="$(resolve_sukisu_ref "$SUKISU_REF susfs_new susfs-main susfs-1.5.13 susfs-1.5.12 susfs-1.5.11 susfs-test main" | tail -n1)" \
        || die "无法解析 SukiSU 引用 '$SUKISU_REF'（已尝试: susfs_new susfs-main susfs-1.5.13 susfs-1.5.12 susfs-1.5.11 susfs-test main）；请核对上方列出的远程分支名，或在 workflow 参数 sukisu_ref 中指定正确的分支"
    echo "      SukiSU resolved: $RESOLVED @ $(git rev-parse --short HEAD)"
    # susfs 说明：SukiSU-Ultra 各分支（main/susfs_new）内核本身不含 susfs 代码，
    # 内核侧 susfs 由下一步 susfs4ksu 集成（那里会做权威验证）。
    if grep -rq 'KSU_SUSFS' kernel/ 2>/dev/null; then
        echo "      [OK] SukiSU 源码自带 susfs 代码"
    else
        echo "      [INFO] SukiSU 内核本身不含 susfs（正常，下一步由 susfs4ksu 集成）"
    fi
    cd "$WORK/kernel"
    # replicate official kernel/setup.sh integration
    ln -sfn "$(realpath --relative-to=drivers "$WORK/KernelSU/kernel")" drivers/kernelsu
    grep -q 'kernelsu' drivers/Makefile || printf "\nobj-\$(CONFIG_KSU) += kernelsu/\n" >> drivers/Makefile
    grep -q 'drivers/kernelsu/Kconfig' drivers/Kconfig || sed -i "/endmenu/i\source \"drivers/kernelsu/Kconfig\"" drivers/Kconfig
fi

# ---------- 5. susfs4ksu 内核侧 susfs 集成（GKI 补丁方式）----------
# 参考社区已验证配方（wtongxue7/OnePlus_SukiSU-Ultra_susfs）：
# 克隆 susfs4ksu 的 gki-<安卓>-<内核> 分支（本机 = gki-android12-5.10）
# → 拷贝 kernel_patches/{fs,include/linux} → 应用 50_add_susfs_in_gki-*.patch
# → 验证内核树出现 KSU_SUSFS。
SUSFS_VARIANT="${4:-auto}"   # 兼容参数；本配方按 GKI 分支自动选择
if [ "$SUKISU_REF" = "none" ] || [ "$SUSFS_VARIANT" = "none" ]; then
    log "Skipping susfs kernel integration"
else
    log "Integrating susfs4ksu kernel code (GKI patch method)"
    # 1) 克隆 susfs4ksu（GitLab 正源，GitHub 镜像兜底；全量克隆以便切分支）
    if [ ! -d "$WORK/susfs4ksu/.git" ]; then
        echo "      susfs: 可用 gki-* 分支（供诊断）:"
        git ls-remote --heads https://gitlab.com/simonpunk/susfs4ksu.git 2>/dev/null | grep -o 'refs/heads/gki-[^ ]*' | sort | head -n 20 || true
        git clone https://gitlab.com/simonpunk/susfs4ksu "$WORK/susfs4ksu" 2>"$WORK/susfs_clone.log" \
            || git clone https://github.com/wspyams/susfs4ksu "$WORK/susfs4ksu" 2>>"$WORK/susfs_clone.log" \
            || { cat "$WORK/susfs_clone.log"; die "susfs4ksu 仓库克隆失败（GitLab 与 GitHub 镜像均不可用）"; }
    fi
    # 2) 选择 gki-* 分支：优先 gki-android12-5.10，其次自动探测含 5.10 的 gki 分支
    cd "$WORK/susfs4ksu"
    susfs_branch=""
    for cand in gki-android12-5.10 gki-android12-5.10-dev; do
        if git rev-parse --verify "refs/remotes/origin/$cand" >/dev/null 2>&1; then
            git checkout -f "$cand" >/dev/null 2>&1 && { susfs_branch="$cand"; break; }
        fi
    done
    if [ -z "$susfs_branch" ]; then
        susfs_branch="$(git branch -r 2>/dev/null | grep -i 'gki.*5\.10' | head -n1 | sed 's/.*origin\///' | tr -d ' ')"
        if [ -n "$susfs_branch" ]; then
            git checkout -f "$susfs_branch" >/dev/null 2>&1 || susfs_branch=""
        fi
    fi
    if [ -z "$susfs_branch" ]; then
        echo "      [warn] 未找到 gki-*5.10* 分支，使用默认分支（可能不匹配）"
        susfs_branch="默认"
    fi
    echo "      susfs4ksu branch: $susfs_branch ($(git rev-parse --short HEAD 2>/dev/null))"
    # 3) 定位补丁文件
    patch_file=""
    for p in "$WORK/susfs4ksu/kernel_patches/50_add_susfs_in_gki-android12-5.10.patch" \
             "$WORK/susfs4ksu/kernel_patches/"50_add_susfs_in_gki-*.patch; do
        [ -f "$p" ] && { patch_file="$p"; break; }
    done
    if [ -z "$patch_file" ]; then
        echo "      kernel_patches/ 内容:"
        ls -1 "$WORK/susfs4ksu/kernel_patches/" 2>/dev/null | head -n 20 || echo "      (目录不存在)"
        die "未找到 50_add_susfs_in_gki-*.patch"
    fi
    echo "      susfs patch: ${patch_file#$WORK/susfs4ksu/}"
    # 4) 拷贝支持文件 + 打补丁（内核树根，无 common/ 子目录）
    cd "$WORK/kernel"
    if [ -d "$WORK/susfs4ksu/kernel_patches/fs" ]; then
        cp -r "$WORK/susfs4ksu/kernel_patches/fs/." fs/ && echo "      [OK] 已拷贝 kernel_patches/fs/* -> fs/"
    fi
    if [ -d "$WORK/susfs4ksu/kernel_patches/include/linux" ]; then
        cp -r "$WORK/susfs4ksu/kernel_patches/include/linux/." include/linux/ && echo "      [OK] 已拷贝 kernel_patches/include/linux/* -> include/linux/"
    fi
    echo "      applying susfs patch ..."
    patch -p1 < "$patch_file" >"$WORK/susfs_patch.log" 2>&1 || true
    tail -n 15 "$WORK/susfs_patch.log"
    # 5) 权威验证：内核树出现 KSU_SUSFS 才算成功
    if grep -rq 'KSU_SUSFS' . 2>/dev/null; then
        echo "      [OK] susfs 内核代码集成成功（检出 CONFIG_KSU_SUSFS）"
    else
        die "susfs 补丁应用后未检出 KSU_SUSFS！请查看上方补丁输出"
    fi
fi

# ---------- 5+6. configure & build (with clang fallback) ----------
# apply SukiSU/susfs fragment to the build .config via scripts/config (idempotent)
apply_fragment() {
    local frag="$1" cfg="$2"
    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            ''|\#*) continue ;;
            CONFIG_*=y)
                opt="${line#CONFIG_}"; opt="${opt%=y}"
                ./scripts/config --file "$cfg" -e "$opt" ;;
            CONFIG_*=m)
                opt="${line#CONFIG_}"; opt="${opt%=m}"
                ./scripts/config --file "$cfg" -m "$opt" ;;
            CONFIG_*=n)
                opt="${line#CONFIG_}"; opt="${opt%=n}"
                ./scripts/config --file "$cfg" -d "$opt" ;;
        esac
    done < "$frag"
}

build_attempt() {
    local ver="$1"
    local dir
    dir="$(download_clang "$ver" | tail -n1)" || { echo "      [warn] clang $ver unavailable"; return 1; }
    export PATH="$dir/bin:$PATH"
    echo "      using $(clang --version | head -n1)"
    rm -rf "$BUILD"; mkdir -p "$BUILD"
    make O="$BUILD" ARCH=arm64 CC=clang LLVM=1 CLANG_TRIPLE=aarch64-linux-gnu- gki_defconfig
    if [ "$SUKISU_REF" != "none" ] && [ -f "$SRC_ROOT/configs/gki-sukisu.config" ]; then
        apply_fragment "$SRC_ROOT/configs/gki-sukisu.config" "$BUILD/.config"
        make O="$BUILD" ARCH=arm64 CC=clang LLVM=1 CLANG_TRIPLE=aarch64-linux-gnu- olddefconfig
    fi
    echo "      KSU/SUSFS options in .config:"
    grep -E '^CONFIG_(KSU|KSU_SUSFS|KPM)' "$BUILD/.config" || true
    make O="$BUILD" ARCH=arm64 CC=clang LLVM=1 CLANG_TRIPLE=aarch64-linux-gnu- -j"$(nproc)" Image
}

log "Configuring & building (first attempt with $CLANG_VERSION)"
BUILD_CLANG=""
for ver in "$CLANG_VERSION" "clang-r450784d" "clang-r487747c"; do
    echo ""
    log "--- build attempt: clang $ver ---"
    if build_attempt "$ver"; then
        BUILD_CLANG="$ver"
        break
    fi
    echo "      [warn] build with $ver failed, trying next clang ..."
done
[ -n "$BUILD_CLANG" ] || die "all clang build attempts failed"
log "Build succeeded with clang $BUILD_CLANG"

IMAGE="$BUILD/arch/arm64/boot/Image"
[ -f "$IMAGE" ] || die "Image not produced"
ls -lh "$IMAGE"

# ---------- 7. verify ----------
log "Verifying built kernel"
strings "$IMAGE" | grep -m1 'Linux version' || true
strings "$IMAGE" | grep -m1 'susfs is initialized' || true
python3 - "$IMAGE" "$OUT/built.config" <<'PYEOF'
import sys, gzip
data = open(sys.argv[1], 'rb').read()
s = data.index(b'IKCFG_ST') + len(b'IKCFG_ST')
e = data.index(b'IKCFG_ED')
open(sys.argv[2], 'wb').write(gzip.decompress(data[s:e]))
print('[+] built .config extracted ->', sys.argv[2])
PYEOF
echo "      verified options in built kernel:"
grep -E '^CONFIG_(KSU=|KSU_SUSFS=|KPM)' "$OUT/built.config" || true

# ---------- 8. package AnyKernel3 zip ----------
log "Packaging AnyKernel3 zip"
# web-uploaded files may have lost exec bits; restore them
chmod -R +x "$SRC_ROOT/template/tools" 2>/dev/null || true
PKG="$WORK/package"
rm -rf "$PKG"; mkdir -p "$PKG"
cp -r "$SRC_ROOT/template/." "$PKG/"
cp "$IMAGE" "$PKG/Image"
STAMP="$(date +%Y%m%d)"
ZIPNAME="5.10_SukiSU_Ultra_lz4kd_${SUKISU_REF}_${STAMP}.zip"
(cd "$PKG" && zip -r9 "$OUT/$ZIPNAME" . -x '*.git*' >/dev/null)
ls -lh "$OUT/$ZIPNAME"
echo "============================================"
echo " DONE. Flashable zip: $OUT/$ZIPNAME"
echo " Built config saved:  $OUT/built.config"
echo "============================================"
