#!/usr/bin/env bash
# ============================================================
# Build SukiSU Ultra GKI 5.10 kernel for realme GT Neo5 (RMX3706)
#
# Rebuild of xiaoxiaow's "5.10_SukiSU_Ultra_lz4kd_40085" package
# using the LATEST SukiSU Ultra source (official susfs branch),
# GKI base android12-5.10 @ 5.10.236 (matches the device's ROM).
#
# Usage: ./build_kernel.sh [kernel_tag] [sukisu_ref] [clang_version] [susfs_variant]
#   kernel_tag : "auto" (find tag with SUBLEVEL=236) or e.g. android12-5.10-2025-05_r1
#   sukisu_ref : susfs_new (default, SukiSU 官方分支) | main | 提交号 | none
#   clang_version : AOSP clang dir name, default clang-r416183b (clang 12.0.5, matches stock)
#   susfs_variant : auto (默认, 自动尝试 SukiSU/kernelSU-Next/kernelSU) | 指定变体 | none
# ============================================================
set -euo pipefail

KERNEL_TAG_ARG="${1:-auto}"
SUKISU_REF="${2:-susfs_new}"
CLANG_VERSION="${3:-clang-r416183b}"

SRC_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="$SRC_ROOT/work"
OUT="$SRC_ROOT/out"
BUILD="$WORK/build"
mkdir -p "$WORK" "$OUT"

log() { echo "[+] $*"; }
die() { echo "[ERROR] $*" >&2; exit 1; }

# ---------- 0. pre-flight checks ----------
[ -d "$SRC_ROOT/template/tools" ] || die "template/tools 目录缺失：请确认已上传整个 template/（含 magiskboot、httools 等文件）"
[ -f "$SRC_ROOT/configs/gki-sukisu.config" ] || die "configs/gki-sukisu.config 缺失"

# ---------- 1. resolve AOSP kernel tag (SUBLEVEL = 236) ----------
resolve_kernel_tag() {
    if [ "$KERNEL_TAG_ARG" != "auto" ]; then echo "$KERNEL_TAG_ARG"; return; fi
    local months="2024-11_r1 2024-12_r1 2025-01_r1 2025-02_r1 2025-03_r1 2025-04_r1 2025-05_r1 2025-06_r1 2025-07_r1 2025-08_r1 2025-09_r1 2025-10_r1"
    local last=""
    local tag sl
    for m in $months; do
        tag="android12-5.10-$m"
        sl=""
        sl=$(curl -fsSL "https://android.googlesource.com/kernel/common/+/refs/tags/$tag/Makefile?format=TEXT" 2>/dev/null \
             | base64 -d 2>/dev/null | awk '/^SUBLEVEL/{print $3; exit}' || true)
        echo "      probe $tag -> SUBLEVEL=${sl:-?}" >&2
        if [ -n "$sl" ]; then last="$tag"; fi
        if [ "$sl" = "236" ]; then echo "$tag"; return; fi
    done
    if [ -n "$last" ]; then
        echo "      [warn] no tag with SUBLEVEL=236 found; using last existing tag: $last" >&2
        echo "$last"
    else
        echo "android12-5.10-2025-05_r1"
    fi
}
log "Resolving AOSP kernel tag ..."
KERNEL_TAG="$(resolve_kernel_tag | tail -n1)"
echo "      >> kernel tag = $KERNEL_TAG"

# ---------- 2. clone kernel source ----------
if [ ! -d "$WORK/kernel/.git" ]; then
    log "Cloning kernel/common @ $KERNEL_TAG (shallow)"
    git clone --depth 1 --branch "$KERNEL_TAG" \
        https://android.googlesource.com/kernel/common "$WORK/kernel"
fi
cd "$WORK/kernel"

# ---------- 3. AOSP clang toolchain ----------
download_clang() {
    local ver="$1" dir="$WORK/clang-$ver"
    if [ -x "$dir/bin/clang" ]; then echo "$dir"; return; fi
    log "Downloading AOSP clang: $ver"
    mkdir -p "$dir"
    local ok=0 br
    for br in master-kernel-build-2021 master-kernel-build-2022 master-kernel-build-2023 main; do
        local url="https://android.googlesource.com/platform/prebuilts/clang/host/linux-x86/+archive/refs/heads/$br/$ver.tar.gz"
        echo "      trying $url" >&2
        if curl -fsSL --retry 3 "$url" -o "$WORK/clang-$ver.tar.gz"; then
            tar -xf "$WORK/clang-$ver.tar.gz" -C "$dir" && ok=1 && break
        fi
    done
    [ "$ok" = 1 ] || return 1
    echo "$dir"
}

# ---------- 4. integrate SukiSU Ultra (+ susfs branch) ----------
# 解析 SukiSU 引用：全量克隆（所有分支可用）→ 按优先级检出（显式指定 → 常用 susfs 分支 → main），
# 并验证源码中确实包含 susfs 代码（防止静默丢失隐藏功能）。
resolve_sukisu_ref() {
    local refs="$1" ref
    for ref in $refs; do
        echo "      trying ref: $ref" >&2
        if git rev-parse --verify "refs/remotes/origin/$ref" >/dev/null 2>&1; then
            git checkout -f "$ref" >/dev/null 2>&1 && { echo "$ref"; return 0; }
        elif git rev-parse --verify "refs/tags/$ref" >/dev/null 2>&1; then
            git checkout -f "refs/tags/$ref" >/dev/null 2>&1 && { echo "$ref"; return 0; }
        elif git rev-parse --verify "$ref^{commit}" >/dev/null 2>&1; then
            git checkout -f "$ref" >/dev/null 2>&1 && { echo "$ref"; return 0; }
        fi
    done
    return 1
}

if [ "$SUKISU_REF" = "none" ]; then
    log "Skipping SukiSU integration (sukisu_ref=none)"
else
    log "Integrating SukiSU Ultra @ $SUKISU_REF"
    if [ ! -d "$WORK/KernelSU/.git" ]; then
        # 全量克隆（不用浅克隆）：所有分支都会成为远程跟踪分支，检出最可靠
        git clone https://github.com/SukiSU-Ultra/SukiSU-Ultra "$WORK/KernelSU"
    fi
    cd "$WORK/KernelSU"
    echo "      remote susfs refs available:"
    git ls-remote --heads --tags origin 2>/dev/null | grep -i susfs || echo "      (远程无 susfs 分支/tag)"
    RESOLVED="$(resolve_sukisu_ref "$SUKISU_REF susfs_new susfs-main susfs-1.5.13 susfs-1.5.12 susfs-1.5.11 susfs-test main" | tail -n1)" \
        || die "无法解析 SukiSU 引用 '$SUKISU_REF'（已尝试: susfs_new susfs-main susfs-1.5.13 susfs-1.5.12 susfs-1.5.11 susfs-test main）；请核对上方列出的远程分支名，或在 workflow 参数 sukisu_ref 中指定正确的分支"
    echo "      SukiSU resolved: $RESOLVED @ $(git rev-parse --short HEAD)"
    # susfs 说明：SukiSU-Ultra 各分支（main/susfs_new）内核本身不含 susfs 代码，
    # 内核侧 susfs 由下一步 susfs4ksu 集成（那里会做权威验证）。
    if grep -rq 'KSU_SUSFS' kernel/ 2>/dev/null; then
        echo "      [OK] SukiSU 源码自带 susfs 代码"
    else
        echo "      [INFO] SukiSU 内核本身不含 susfs（正常，下一步由 susfs4ksu 集成）"
    fi
    cd "$WORK/kernel"
    # replicate official kernel/setup.sh integration
    ln -sfn "$(realpath --relative-to=drivers "$WORK/KernelSU/kernel")" drivers/kernelsu
    grep -q 'kernelsu' drivers/Makefile || printf "\nobj-\$(CONFIG_KSU) += kernelsu/\n" >> drivers/Makefile
    grep -q 'drivers/kernelsu/Kconfig' drivers/Kconfig || sed -i "/endmenu/i\source \"drivers/kernelsu/Kconfig\"" drivers/Kconfig
fi

# ---------- 5. susfs4ksu 内核侧 susfs 集成 ----------
# 注意：SukiSU-Ultra 仓库（main / susfs_new）的内核本身不含 susfs 代码，
# 内核侧 susfs 需单独集成 susfs4ksu。正源在 GitLab（simonpunk/susfs4ksu，master 分支），
# GitHub 有镜像（wspyams/susfs4ksu）。采用：克隆仓库 → 尝试 ksu-next/master 分支 →
# 运行其 setup.sh（多变体 + 无参尝试）→ 验证 KSU_SUSFS。
SUSFS_VARIANT="${4:-auto}"   # auto | SukiSU | kernelSU-Next | kernelSU | none
if [ "$SUKISU_REF" = "none" ] || [ "$SUSFS_VARIANT" = "none" ]; then
    log "Skipping susfs kernel integration"
else
    log "Integrating susfs4ksu kernel code (variant=$SUSFS_VARIANT)"
    # 1) 克隆 susfs4ksu（GitLab 正源，GitHub 镜像兜底；全量克隆以便切换分支）
    if [ ! -d "$WORK/susfs4ksu/.git" ]; then
        git clone https://gitlab.com/simonpunk/susfs4ksu "$WORK/susfs4ksu" 2>"$WORK/susfs_clone.log" \
            || git clone https://github.com/wspyams/susfs4ksu "$WORK/susfs4ksu" 2>>"$WORK/susfs_clone.log" \
            || { cat "$WORK/susfs_clone.log"; die "susfs4ksu 仓库克隆失败（GitLab 与 GitHub 镜像均不可用）"; }
    fi
    # 2) 确定分支：优先 ksu-next（面向 KernelSU-Next/SukiSU），否则 master
    cd "$WORK/susfs4ksu"
    susfs_branch=""
    for br in ksu-next master main; do
        if git rev-parse --verify "refs/remotes/origin/$br" >/dev/null 2>&1; then
            git checkout -f "$br" >/dev/null 2>&1 && { susfs_branch="$br"; break; }
        fi
    done
    [ -n "$susfs_branch" ] || { echo "      [warn] 无法检出 susfs4ksu 分支，使用默认 HEAD"; susfs_branch="HEAD"; }
    echo "      susfs4ksu branch: $susfs_branch ($(git rev-parse --short HEAD))"
    # 3) 定位 setup.sh（kernel/setup.sh 或仓库根 setup.sh）
    susfs_setup=""
    for p in "$WORK/susfs4ksu/kernel/setup.sh" "$WORK/susfs4ksu/setup.sh"; do
        [ -f "$p" ] && { susfs_setup="$p"; break; }
    done
    [ -n "$susfs_setup" ] || die "susfs4ksu 仓库中未找到 setup.sh（kernel/setup.sh 与根 setup.sh 均不存在）"
    echo "      susfs setup.sh: ${susfs_setup#$WORK/susfs4ksu/}"
    # 4) 在 kernel 树中运行 setup.sh：多变体 + 无参尝试，验证 KSU_SUSFS
    cd "$WORK/kernel"
    if [ "$SUSFS_VARIANT" = "auto" ]; then
        variants="SukiSU kernelSU-Next kernelSU"
    else
        variants="$SUSFS_VARIANT"
    fi
    susfs_ok=0
    attempt_susfs() {
        local label="$1"; shift
        echo "      susfs: trying variant '$label'" >&2
        if bash "$susfs_setup" "$@" >"$WORK/susfs_setup.log" 2>&1; then
            if grep -rq 'KSU_SUSFS' "$WORK/KernelSU/kernel/" 2>/dev/null; then
                echo "      [OK] susfs 内核代码集成成功（variant=$label, 检出 CONFIG_KSU_SUSFS）"
                return 0
            fi
        fi
        echo "      [warn] variant '$label' 未检出 KSU_SUSFS，尝试下一个 ..."
        return 1
    }
    for variant in $variants; do
        if attempt_susfs "$variant" "$variant"; then susfs_ok=1; break; fi
    done
    if [ "$susfs_ok" != "1" ] && [ "$SUSFS_VARIANT" = "auto" ]; then
        if attempt_susfs "<no-arg>"; then susfs_ok=1; fi
    fi
    if [ "$susfs_ok" != "1" ]; then
        echo "      --- 最后一次 susfs setup.sh 输出（诊断）---"
        tail -n 30 "$WORK/susfs_setup.log" 2>/dev/null || true
        die "susfs4ksu 集成失败（branch=$susfs_branch, 已尝试变体: $variants + 无参）。请参考 susfs4ksu 的集成说明，确认 SukiSU 对应的分支/变体名"
    fi
fi

# ---------- 5+6. configure & build (with clang fallback) ----------
# apply SukiSU/susfs fragment to the build .config via scripts/config (idempotent)
apply_fragment() {
    local frag="$1" cfg="$2"
    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            ''|\#*) continue ;;
            CONFIG_*=y)
                opt="${line#CONFIG_}"; opt="${opt%=y}"
                ./scripts/config --file "$cfg" -e "$opt" ;;
            CONFIG_*=m)
                opt="${line#CONFIG_}"; opt="${opt%=m}"
                ./scripts/config --file "$cfg" -m "$opt" ;;
            CONFIG_*=n)
                opt="${line#CONFIG_}"; opt="${opt%=n}"
                ./scripts/config --file "$cfg" -d "$opt" ;;
        esac
    done < "$frag"
}

build_attempt() {
    local ver="$1"
    local dir
    dir="$(download_clang "$ver" | tail -n1)" || { echo "      [warn] clang $ver unavailable"; return 1; }
    export PATH="$dir/bin:$PATH"
    echo "      using $(clang --version | head -n1)"
    rm -rf "$BUILD"; mkdir -p "$BUILD"
    make O="$BUILD" ARCH=arm64 CC=clang LLVM=1 CLANG_TRIPLE=aarch64-linux-gnu- gki_defconfig
    if [ "$SUKISU_REF" != "none" ] && [ -f "$SRC_ROOT/configs/gki-sukisu.config" ]; then
        apply_fragment "$SRC_ROOT/configs/gki-sukisu.config" "$BUILD/.config"
        make O="$BUILD" ARCH=arm64 CC=clang LLVM=1 CLANG_TRIPLE=aarch64-linux-gnu- olddefconfig
    fi
    echo "      KSU/SUSFS options in .config:"
    grep -E '^CONFIG_(KSU|KSU_SUSFS|KPM)' "$BUILD/.config" || true
    make O="$BUILD" ARCH=arm64 CC=clang LLVM=1 CLANG_TRIPLE=aarch64-linux-gnu- -j"$(nproc)" Image
}

log "Configuring & building (first attempt with $CLANG_VERSION)"
BUILD_CLANG=""
for ver in "$CLANG_VERSION" "clang-r450784d" "clang-r487747c"; do
    echo ""
    log "--- build attempt: clang $ver ---"
    if build_attempt "$ver"; then
        BUILD_CLANG="$ver"
        break
    fi
    echo "      [warn] build with $ver failed, trying next clang ..."
done
[ -n "$BUILD_CLANG" ] || die "all clang build attempts failed"
log "Build succeeded with clang $BUILD_CLANG"

IMAGE="$BUILD/arch/arm64/boot/Image"
[ -f "$IMAGE" ] || die "Image not produced"
ls -lh "$IMAGE"

# ---------- 7. verify ----------
log "Verifying built kernel"
strings "$IMAGE" | grep -m1 'Linux version' || true
strings "$IMAGE" | grep -m1 'susfs is initialized' || true
python3 - "$IMAGE" "$OUT/built.config" <<'PYEOF'
import sys, gzip
data = open(sys.argv[1], 'rb').read()
s = data.index(b'IKCFG_ST') + len(b'IKCFG_ST')
e = data.index(b'IKCFG_ED')
open(sys.argv[2], 'wb').write(gzip.decompress(data[s:e]))
print('[+] built .config extracted ->', sys.argv[2])
PYEOF
echo "      verified options in built kernel:"
grep -E '^CONFIG_(KSU=|KSU_SUSFS=|KPM)' "$OUT/built.config" || true

# ---------- 8. package AnyKernel3 zip ----------
log "Packaging AnyKernel3 zip"
# web-uploaded files may have lost exec bits; restore them
chmod -R +x "$SRC_ROOT/template/tools" 2>/dev/null || true
PKG="$WORK/package"
rm -rf "$PKG"; mkdir -p "$PKG"
cp -r "$SRC_ROOT/template/." "$PKG/"
cp "$IMAGE" "$PKG/Image"
STAMP="$(date +%Y%m%d)"
ZIPNAME="5.10_SukiSU_Ultra_lz4kd_${SUKISU_REF}_${STAMP}.zip"
(cd "$PKG" && zip -r9 "$OUT/$ZIPNAME" . -x '*.git*' >/dev/null)
ls -lh "$OUT/$ZIPNAME"
echo "============================================"
echo " DONE. Flashable zip: $OUT/$ZIPNAME"
echo " Built config saved:  $OUT/built.config"
echo "============================================"
