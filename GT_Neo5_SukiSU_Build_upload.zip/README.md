# GT Neo5 (RMX3706) SukiSU Ultra GKI 内核 · 云编译工作流

基于你现有的 `5.10_SukiSU_Ultra_lz4kd_40085.zip`（xiaoxiaow 构建）更新而来：

| 项目 | 旧包 | 新包 |
|---|---|---|
| 内核基线 | GKI 5.10.226-android12 | **GKI 5.10.236-android12**（与你当前 ROM 一致） |
| SukiSU Ultra | KSU 版本 40085（旧 KernelSU-Next 底） | **最新 main 分支源码（v3.x 内核框架）** |
| susfs | v1.5.12 | **官方最新 susfs-main 分支** |
| hook 方式 | 旧式手动 hook（KSU_MANUAL_HOOK） | 新版默认 **kprobe hook**（GKI 官方推荐，行为等效） |
| 功能配置 | 见下 | 与旧包 **1:1 复刻**（从旧内核 IKCONFIG 提取） |
| KPM | 无 | 无（默认关闭） |
| 刷机包装配 | AnyKernel3 + httools/lptools（OPPO/真我系） | **完全相同**（沿用原包装，刷机方式不变） |

保留的功能（与旧包一致）：susfs 全套隐藏 —— SUS_PATH / SUS_MOUNT / SUS_KSTAT / TRY_UMOUNT /
SPOOF_UNAME / OPEN_REDIRECT / SUS_MAP / 自动挂载隐藏 / 隐藏 KSU 符号 / 伪造 cmdline 等，无 KPM。

---

## 目录结构

```
├── .github/workflows/build-kernel.yml   # GitHub Actions 云编译工作流
├── build_kernel.sh                      # 主构建脚本（下载源码/工具链→集成→编译→打包→校验）
├── configs/gki-sukisu.config            # SukiSU/susfs 配置片段（复刻自旧包）
├── template/                            # AnyKernel3 刷机包装配（沿用旧包）
│   ├── anykernel.sh                     # 仅改了 kernel.string，刷机逻辑与原包一致
│   ├── tools/                           # magiskboot / httools / lptools 等
│   └── META-INF/                        # 刷机脚本
└── README.md
```

## 使用方法（GitHub Actions 云编译）

### 第一步：把工程上传到 GitHub

1. 打开 [github.com](https://github.com)，注册/登录账号（若还没有）。
2. 右上角 **+** → **New repository** → 名称随意（如 `GT-Neo5-SukiSU`）→ 选 **Public** 或 **Private** 均可 → **Create repository**。
3. 在新仓库页面点 **uploading an existing file**（或拖拽），把 `GT_Neo5_SukiSU_Build_upload.zip` **解压后的所有内容**拖进去——**务必保持目录结构**（`.github/workflows/`、`build_kernel.sh`、`configs/`、`template/` 都在，尤其 `template/tools/` 里的二进制文件不能漏）。
4. 填 Commit message（随意）→ **Commit changes**。

### 第二步：运行云编译

1. 仓库页面顶部点 **Actions** 标签。
2. 左侧点 **"Build SukiSU Ultra GKI Kernel (GT Neo5 / RMX3706)"**。
3. 右侧 **Run workflow** 下拉按钮 → 直接点 **Run workflow**（参数保持默认）。
4. 等待构建（首次约 1~2 小时；日志里能看到 `probe ... -> SUBLEVEL=236`、SukiSU HEAD、`Build succeeded` 等关键行）。

### 第三步：下载产物

1. 构建完成后，点进该次运行记录，页面底部 **Artifacts** 区域下载 `GT_Neo5_SukiSU_Ultra_Kernel`。
2. 解压后得到：
   - `5.10_SukiSU_Ultra_lz4kd_susfs-main_YYYYMMDD.zip` —— **可刷入的刷机包**；
   - `built.config` —— 新内核完整配置（可发给作者核对功能选项）。

### 参数说明（一般不用改）

| 参数 | 默认值 | 说明 |
|---|---|---|
| kernel_tag | auto | 自动探测 AOSP `android12-5.10` 中 `SUBLEVEL=236` 的 tag（若该版本无对应 tag 则自动使用最后一个存在的 tag，KMI 兼容）；也可手填如 `android12-5.10-2025-05_r1` |
| sukisu_ref | susfs-main | SukiSU 源码引用：`susfs-main`=官方维护的最新 SukiSU+susfs（推荐）；`main`=不带 susfs；`susfs-1.5.x`=指定版本；`none`=不集成 |
| clang_version | clang-r416183b | AOSP clang（clang 12.0.5，与你原厂内核同一工具链，KMI/ABI 最稳）；若该版本编译失败，脚本会自动依次尝试 clang-r450784d → clang-r487747c |

## 刷机（与原 40085 包完全相同）

> ⚠️ 刷机前**务必先备份当前 boot**（fastboot 或 Recovery 备份原 boot.img），并确保已解锁 Bootloader。

- 推荐方式：第三方 Recovery（TWRP/OrangeFox 等）里 **Install** 刷入 zip；
- 或手动：解包 zip 取出 `Image`，`fastboot flash boot Image`（若设备用 init_boot 分区则刷 init_boot）。
- 首次开机可能稍慢属正常；开不了机就 fastboot 刷回原 boot.img。

## 刷入后验证

1. 打开 **SukiSU Ultra 管理器**（从 [SukiSU-Ultra Releases](https://github.com/SukiSU-Ultra/SukiSU-Ultra/releases) 下载最新版），
   应能看到内核已变为新版本（不再是 40085），并可正常授权 root。
2. 终端执行 `uname -a`，应显示 `5.10.236-android12-...`。
3. susfs 隐藏功能在管理器/相应模块中可正常使用。

## boot.img 验证结果（已分析 F:\deepseek\boot.img）

| 项目 | 结果 | 结论 |
|---|---|---|
| 镜像类型 | **v4 boot 镜像**（`ANDROID!` + header v4，signature_size=4096） | magiskboot 支持 ✓ |
| 分区结构 | **boot 分区 = 内核 + ramdisk**（无 init_boot，内核 4096 对齐） | 刷机包装配走 `dump_boot/write_boot` 分支 ✓ |
| 内核 | 未压缩 arm64 Image，48MB，`5.10.236-android12-9-o-gea605b006921` | 与你当前系统一致，新构建匹配 android12-5.10@5.10.236 ✓ |
| ramdisk | **lz4 legacy 压缩的 cpio**（magic `02 21 4C 18` + `070701`）——即包名 "lz4kd" 的来源 | 刷机包 `ramdisk_compression=auto` 自动处理 ✓ |
| os_version | Android 12 / patch 2026-05（GKI android12-5.10） | 正常：系统升到 Android 16 但内核仍是 android12 GKI ✓ |
| AVB | 带 vbmeta 签名，包装内 httools 自动处理 | ✓ |

## 构建产物说明

- `out/*.zip` —— 可刷入的 AnyKernel3 包（Image 为新编译内核）。
- `out/built.config` —— 新内核的完整 .config（自动从 Image 提取，可核对功能选项）。
- 构建脚本会自动校验：`Linux version` 版本串、`susfs is initialized`、IKCONFIG 里的 KSU/SUSFS 选项。
- **本地自检**：Windows PowerShell 直接跑 `scripts/verify_built_kernel.ps1 <刷机zip或Image>`，会输出内核版本、susfs 版本、功能选项并给出 PASS/FAIL 结论（无需装任何工具）。

## 备用路径：本地 WSL2 / Linux 构建（不用 GitHub 也能编译）

> 主路径是 GitHub Actions 云编译；以下为备用方案，适合不想用 GitHub 的情况。

1. **装 WSL2**：Windows 管理员 PowerShell 执行 `wsl --install -d Ubuntu`，重启后按提示创建账号。
2. **拷贝工程**：把整个 `GT_Neo5_SukiSU_Build` 文件夹拷进 Ubuntu，例如 `cp -r /mnt/f/GT_Neo5_SukiSU_Build ~/`（F 盘会挂载在 `/mnt/f`）。
3. **装依赖**：`cd ~/GT_Neo5_SukiSU_Build && sudo bash scripts/install-deps-ubuntu.sh`
4. **构建**：`./build_kernel.sh`（首次需联网，下载源码+clang 共约 3GB、编译 1~3 小时；中断可重跑，已下载内容会复用）。
5. **产物**：`out/` 下的 `5.10_SukiSU_Ultra_lz4kd_susfs-main_YYYYMMDD.zip` 与云编译完全一致。

## 刷机失败 / 想回滚

- **刷机前**务必已备份原版 boot.img（fastboot 备份或 Recovery 备份）。
- **卡 logo / 反复重启**：进 fastboot，`fastboot flash boot 原版boot.img` 恢复；或 Recovery 里恢复备份。
- **刷入方式**：优先用与 40085 包完全相同的方式（第三方 Recovery 刷 zip），包装已自动处理真我设备的 AVB/分区问题；不建议裸用 `fastboot flash boot` 刷第三方内核。
- **实在不行**：用官方工具刷全量固件包回官方状态，再重新操作。
- **刷完没生效**：确认刷入后第一次开机等 1~2 分钟；仍无 root 则在 SukiSU Ultra 管理器里查看内核版本是否已更新。

## 常见问题

- **为什么用 susfs-main 而不是我本地的 main？**
  你本地的 `SukiSU-Ultra-main` 是 GitHub main 分支的快照（最新版，内容一致）；而官方
  `susfs-main` 分支 = 同版本 SukiSU + 官方维护的 susfs 集成。云编译从 GitHub 直接拉取，
  两者等价且更可靠。若想用你本地的确切文件，可把 `kernel/` 目录打成 zip 上传到仓库，
  或改用本地 WSL2 构建（另行提供脚本）。
- **构建失败？** 查看 Actions 日志；常见为网络抖动，重跑一次即可。clang 编译报错时脚本已内置自动换用更新 clang 重试（r416183b → r450784d → r487747c）。
- **网页上传会丢可执行权限吗？** 会。但构建脚本打包前会自动 `chmod +x template/tools`，无需担心。
- **构建用独立目录**（`work/build`，O= 方式），重复构建自动复用已下载的源码与工具链，更省时间。
- **想加 KPM / ZRAM？** 告诉我，我把配置片段和工作流改好。
- **与当前系统不兼容？** 先核对 `kernel_tag` 是否解析到了 5.10.236（日志中有 `probe` 输出）。
